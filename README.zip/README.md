# responsi_khosyi
Pembuatan WebGIS Informasi Kabupaten Sleman
README
A. Nama produk : SIKAB Sleman
B. Deskripsi produk: website GIS yang membahas terkait informasi seputar Kabupaten Sleman dari segi sosial, lingkungan, dan pemerintahan. Website menampilkan informasi berupa distribusi jumlah penduduk yang menunjukkan indikator kemajuan wilayah, seperti keseimbangan jumlah penduduk dengan fasilitas kesehatan, potensi ekonomi, serta distribusi mitigasi bencana untuk menghindari turunnya persentase jumlah penduduk
C. Komponen pembangun produk: cover (landing page), carousel (dashboard), features, navbars, database spasial, webGIS, infografis, website public
D. Sumber data: BPS Kab Sleman, BPBD Sleman, Stasiun Klimatologi BMKG Provinsi DIY, website Pemerintah Kabupaten Sleman, BPBD Provinsi Yogyakarta
E. Tangkapan layar komponen penting produk:
![Alt text](<Screenshot 2023-11-25 000329.png>) ![Alt text](<Screenshot 2023-11-25 000542.png>) ![Alt text](<Screenshot 2023-11-25 000509.png>) ![Alt text](<Screenshot 2023-11-25 000438.png>) ![Alt text](<Screenshot 2023-11-25 000423.png>)